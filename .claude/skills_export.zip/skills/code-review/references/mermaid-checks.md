# Mermaid Diagram Validation Reference

This document details Mermaid diagram validation performed by the code-review skill.

## Important

For Mermaid validation, Claude must search the web for the latest Mermaid documentation to ensure syntax rules are current. Mermaid syntax evolves frequently, and validation must use up-to-date specifications.

**Always search:** `site:mermaid.js.org` for current syntax documentation.

## Supported Diagram Types

Validate these diagram types:

- **Flowchart** (`flowchart`, `graph`)
- **Sequence Diagram** (`sequenceDiagram`)
- **Class Diagram** (`classDiagram`)
- **State Diagram** (`stateDiagram-v2`)
- **Entity Relationship** (`erDiagram`)
- **Gantt Chart** (`gantt`)
- **Pie Chart** (`pie`)
- **Git Graph** (`gitGraph`)
- **Mindmap** (`mindmap`)
- **Timeline** (`timeline`)
- **Quadrant Chart** (`quadrantChart`)

## Common Validation Checks

### Syntax Errors (Severity: ERROR)

1. **Missing diagram type declaration**
   ```mermaid
   A --> B  <!-- Missing: flowchart TD -->
   ```

2. **Invalid node/edge syntax**
   ```mermaid
   flowchart TD
   A -> B  <!-- Should be --> or --- -->
   ```

3. **Unclosed brackets or quotes**
   ```mermaid
   flowchart TD
   A[Unclosed node
   ```

4. **Invalid characters in identifiers**

### Structural Issues (Severity: WARNING)

1. **Undefined nodes referenced**
   ```mermaid
   flowchart TD
   A --> B
   C --> D  <!-- D never defined with content -->
   ```

2. **Disconnected subgraphs** - Nodes not connected to main flow

3. **Circular references without proper handling**

### Style Issues (Severity: INFO)

1. **Inconsistent naming conventions**
2. **Missing node labels**
3. **Overly complex single diagrams** (should be split)

## Diagram-Specific Rules

### Flowcharts

```mermaid
flowchart TD
    A[Start] --> B{Decision}
    B -->|Yes| C[Action]
    B -->|No| D[Other Action]
```

- Direction must be: `TB`, `TD`, `BT`, `RL`, `LR`
- Node shapes: `[]` rectangle, `()` rounded, `{}` diamond, `[[]]` subroutine
- Arrow types: `-->`, `---`, `-.->`, `==>`, `--text-->`

### Sequence Diagrams

```mermaid
sequenceDiagram
    participant A as Alice
    participant B as Bob
    A->>B: Hello
    B-->>A: Hi
```

- Participants should be declared
- Arrow types: `->>`, `-->>`, `-x`, `--x`, `-)`, `--)`
- Activations: `activate`/`deactivate` or `+`/`-` suffix

### Class Diagrams

```mermaid
classDiagram
    class Animal {
        +String name
        +makeSound() void
    }
    Animal <|-- Dog
```

- Relationships: `<|--`, `*--`, `o--`, `-->`, `-->`
- Visibility: `+` public, `-` private, `#` protected, `~` package

### State Diagrams

```mermaid
stateDiagram-v2
    [*] --> Idle
    Idle --> Processing : start
    Processing --> [*] : done
```

- Use `[*]` for start/end states
- Transitions: `-->` with optional `:` label

### ER Diagrams

```mermaid
erDiagram
    CUSTOMER ||--o{ ORDER : places
    ORDER ||--|{ LINE-ITEM : contains
```

- Cardinality: `||`, `o|`, `}|`, `}o`, `|{`, `o{`
- All entities should have relationships

## Validation Process

1. **Parse diagram type** from first line
2. **Search latest Mermaid docs** for type-specific syntax
3. **Validate structural syntax** (brackets, arrows, keywords)
4. **Check semantic correctness** (referenced nodes exist)
5. **Report issues with line numbers and suggestions**

## Auto-Fix Capabilities

Limited auto-fix support:

- Fix common arrow syntax (`->` to `-->`)
- Add missing diagram type declaration
- Fix quote mismatches

Most Mermaid issues require manual review due to semantic complexity.
